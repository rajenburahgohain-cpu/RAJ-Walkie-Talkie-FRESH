# RAJ Walkie Talkie — NEW Auth + Google Play Billing Build

This build keeps the native Android voice architecture and adds:

- Supabase email/password sign-up, login, password reset and persistent session.
- Supabase access token passed to the Realtime join payload.
- Foreground microphone service for minimized voice sessions.
- Automatic Realtime reconnect after connection failure.
- Google Play Billing Library 9.1.0 integration for a monthly Premium subscription.
- Premium product ID: `raj_premium_monthly`.
- Purchase acknowledgement and active-subscription restore on app resume.

## Supabase setup

1. In Supabase Authentication, enable Email provider.
2. Decide whether Email Confirmations should be enabled. If enabled, users must confirm their email before login.
3. Configure your production Site URL / redirect URL for password recovery.
4. For production private office authorization, add RLS/policies and use authenticated Realtime channels. The client token is not a substitute for server-side authorization.

The app uses the Supabase publishable key only. No Supabase service-role secret is included.

## Google Play setup — required before a real ₹49/month charge can occur

Create a subscription in Google Play Console with:

- Product ID: `raj_premium_monthly`
- Base plan: monthly recurring plan
- Price: INR 49/month (configure the actual price in Play Console)

The app queries the subscription product from Google Play and launches the Google Play purchase UI. It acknowledges purchased subscriptions and restores active subscriptions.

### Important production security step

A truly secure entitlement system should verify the Google Play purchase token on a backend before granting Premium. This project performs the Play Billing client flow and acknowledgement, but it does not contain Google service-account credentials or a Play Developer API verification backend. Do not put those credentials in the Android app.

For production, verify the purchase token on a secure backend (for example, a Supabase Edge Function/server) and store the Premium entitlement against the authenticated Supabase user.

## Build

Use Android Studio or a Gradle 8.11+ environment compatible with Android Gradle Plugin 8.7.3. The project uses compileSdk 35 and targetSdk 35.

## Billing testing

Use Google Play license testers / Play Console testing tracks and configure the subscription before expecting the Premium product to load. A sideloaded debug APK will not necessarily show a Play Console product unless the Play account and distribution/testing setup are correct.

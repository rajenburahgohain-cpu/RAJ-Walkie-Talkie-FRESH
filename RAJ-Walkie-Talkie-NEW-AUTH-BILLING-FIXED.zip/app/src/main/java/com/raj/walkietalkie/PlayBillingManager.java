package com.raj.walkietalkie;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.android.billingclient.api.*;

import java.util.Collections;
import java.util.List;

public class PlayBillingManager implements PurchasesUpdatedListener {
    public static final String PREMIUM_PRODUCT_ID = "raj_premium_monthly";
    private static final String PREFS = "raj_billing";
    private static final String PREMIUM = "premium_active";

    public interface Listener { void onBillingState(String message, boolean premiumActive); }

    private final Context context;
    private final Listener listener;
    private final SharedPreferences prefs;
    private BillingClient billingClient;
    private ProductDetails premiumProduct;

    public PlayBillingManager(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        billingClient = BillingClient.newBuilder(this.context)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
    }

    public boolean isPremiumActive() { return prefs.getBoolean(PREMIUM, false); }

    public void connect() {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    listener.onBillingState("Google Play Billing connected", isPremiumActive());
                    queryProduct();
                    queryActiveSubscription();
                } else listener.onBillingState("Billing unavailable: " + result.getDebugMessage(), isPremiumActive());
            }
            @Override public void onBillingServiceDisconnected() {
                listener.onBillingState("Google Play Billing disconnected; retrying automatically", isPremiumActive());
            }
        });
    }

    private void queryProduct() {
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(
                        QueryProductDetailsParams.Product.newBuilder()
                                .setProductId(PREMIUM_PRODUCT_ID)
                                .setProductType(BillingClient.ProductType.SUBS)
                                .build()))
                .build();
        billingClient.queryProductDetailsAsync(params, (result, details) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && details != null && !details.getProductDetailsList().isEmpty()) {
                premiumProduct = details.getProductDetailsList().get(0);
                String price = "₹49/month";
                List<ProductDetails.SubscriptionOfferDetails> offers = premiumProduct.getSubscriptionOfferDetails();
                if (offers != null && !offers.isEmpty() && offers.get(0).getPricingPhases() != null && !offers.get(0).getPricingPhases().getPricingPhaseList().isEmpty()) {
                    price = offers.get(0).getPricingPhases().getPricingPhaseList().get(offers.get(0).getPricingPhases().getPricingPhaseList().size()-1).getFormattedPrice() + "/month";
                }
                listener.onBillingState("Premium available: " + price, isPremiumActive());
            } else listener.onBillingState("Premium product not available. Create product '" + PREMIUM_PRODUCT_ID + "' in Play Console.", isPremiumActive());
        });
    }

    public void launchPremium(Activity activity) {
        if (premiumProduct == null) {
            listener.onBillingState("Premium product is not loaded yet. Check Google Play configuration.", isPremiumActive());
            queryProduct();
            return;
        }
        List<ProductDetails.SubscriptionOfferDetails> offers = premiumProduct.getSubscriptionOfferDetails();
        if (offers == null || offers.isEmpty()) {
            listener.onBillingState("No eligible Premium offer is available for this Google Play account.", isPremiumActive());
            return;
        }
        String offerToken = offers.get(0).getOfferToken();
        BillingFlowParams.ProductDetailsParams productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(premiumProduct)
                .setOfferToken(offerToken)
                .build();
        BillingFlowParams flow = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(productParams))
                .build();
        BillingResult result = billingClient.launchBillingFlow(activity, flow);
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK)
            listener.onBillingState("Could not open Google Play Billing: " + result.getDebugMessage(), isPremiumActive());
    }

    private void queryActiveSubscription() {
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS).build();
        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
            boolean active = false;
            for (Purchase purchase : purchases) {
                if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED && purchase.getProducts().contains(PREMIUM_PRODUCT_ID)) {
                    active = true;
                    processPurchase(purchase);
                }
            }
            prefs.edit().putBoolean(PREMIUM, active).apply();
            listener.onBillingState(active ? "Premium active" : "Premium not active", active);
        });
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) if (purchase.getProducts().contains(PREMIUM_PRODUCT_ID)) processPurchase(purchase);
        } else if (result.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
            listener.onBillingState("Google Play purchase canceled", isPremiumActive());
        } else if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            listener.onBillingState("Google Play billing error: " + result.getDebugMessage(), isPremiumActive());
        }
    }

    private void processPurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) {
            listener.onBillingState("Premium purchase is pending; access will activate after Google confirms payment.", isPremiumActive());
            return;
        }
        prefs.edit().putBoolean(PREMIUM, true).apply();
        if (!purchase.isAcknowledged()) {
            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
            billingClient.acknowledgePurchase(params, result -> {
                listener.onBillingState(result.getResponseCode() == BillingClient.BillingResponseCode.OK ? "Premium purchased and acknowledged" : "Premium purchased; acknowledgement pending", true);
            });
        } else listener.onBillingState("Premium active", true);
    }

    public void destroy() { if (billingClient != null && billingClient.isReady()) billingClient.endConnection(); }
}

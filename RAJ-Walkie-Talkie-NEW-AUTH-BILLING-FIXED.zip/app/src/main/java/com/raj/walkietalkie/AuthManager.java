package com.raj.walkietalkie;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.*;

public class AuthManager {
    private static final String PREFS = "raj_auth";
    private static final String ACCESS = "access_token";
    private static final String REFRESH = "refresh_token";
    private static final String EMAIL = "email";

    private final Context context;
    private final String baseUrl;
    private final String apiKey;
    private final OkHttpClient client = new OkHttpClient();
    private final SharedPreferences prefs;

    public AuthManager(Context context, String baseUrl, String apiKey) {
        this.context = context.getApplicationContext();
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean isLoggedIn() { return !prefs.getString(ACCESS, "").isEmpty(); }
    public String getAccessToken() { return prefs.getString(ACCESS, ""); }
    public String getEmail() { return prefs.getString(EMAIL, ""); }

    public void signUp(String email, String password, Callback callback) {
        JSONObject body = new JSONObject();
        try { body.put("email", email); body.put("password", password); }
        catch (Exception e) { callback.onFailure(null, e); return; }
        post("/auth/v1/signup", body.toString(), false, callback);
    }

    public void signIn(String email, String password, Callback callback) {
        JSONObject body = new JSONObject();
        try { body.put("email", email); body.put("password", password); }
        catch (Exception e) { callback.onFailure(null, e); return; }
        post("/auth/v1/token?grant_type=password", body.toString(), false, new Callback() {
            @Override public void onFailure(Call call, IOException e) { callback.onFailure(call, e); }
            @Override public void onResponse(Call call, Response response) throws IOException {
                String text = response.body() == null ? "" : response.body().string();
                if (response.isSuccessful()) saveSession(text, email);
                callback.onResponse(call, ResponseBodyResponse.replace(response, text));
            }
        });
    }

    public void refreshSession(Callback callback) {
        String refresh = prefs.getString(REFRESH, "");
        if (refresh.isEmpty()) { callback.onFailure(null, new IOException("No refresh token")); return; }
        JSONObject body = new JSONObject();
        try { body.put("refresh_token", refresh); }
        catch (Exception e) { callback.onFailure(null, e); return; }
        post("/auth/v1/token?grant_type=refresh_token", body.toString(), false, new Callback() {
            @Override public void onFailure(Call call, IOException e) { callback.onFailure(call, e); }
            @Override public void onResponse(Call call, Response response) throws IOException {
                String text = response.body() == null ? "" : response.body().string();
                if (response.isSuccessful()) saveSession(text, getEmail());
                callback.onResponse(call, ResponseBodyResponse.replace(response, text));
            }
        });
    }

    public void resetPassword(String email, Callback callback) {
        JSONObject body = new JSONObject();
        try { body.put("email", email); }
        catch (Exception e) { callback.onFailure(null, e); return; }
        post("/auth/v1/recover", body.toString(), false, callback);
    }

    public void signOut() {
        String token = getAccessToken();
        if (!token.isEmpty()) {
            Request request = new Request.Builder().url(baseUrl + "/auth/v1/logout")
                    .addHeader("apikey", apiKey).addHeader("Authorization", "Bearer " + token).post(RequestBody.create(new byte[0], null)).build();
            client.newCall(request).enqueue(new Callback() {
                @Override public void onFailure(Call call, IOException e) { clear(); }
                @Override public void onResponse(Call call, Response response) throws IOException { response.close(); clear(); }
            });
        } else clear();
    }

    private void post(String path, String json, boolean bearer, Callback callback) {
        RequestBody rb = RequestBody.create(json, MediaType.get("application/json; charset=utf-8"));
        Request.Builder b = new Request.Builder().url(baseUrl + path)
                .addHeader("apikey", apiKey).addHeader("Content-Type", "application/json").post(rb);
        if (bearer && !getAccessToken().isEmpty()) b.addHeader("Authorization", "Bearer " + getAccessToken());
        client.newCall(b.build()).enqueue(callback);
    }

    private void saveSession(String text, String emailFallback) {
        try {
            JSONObject o = new JSONObject(text);
            String access = o.optString("access_token", "");
            String refresh = o.optString("refresh_token", "");
            JSONObject user = o.optJSONObject("user");
            String email = user != null ? user.optString("email", emailFallback) : emailFallback;
            if (!access.isEmpty()) prefs.edit().putString(ACCESS, access).putString(REFRESH, refresh).putString(EMAIL, email).apply();
        } catch (Exception ignored) {}
    }

    private void clear() { prefs.edit().clear().apply(); }

    private static class ResponseBodyResponse {
        static Response replace(Response original, String body) {
            return original.newBuilder().body(ResponseBody.create(body, MediaType.get("application/json; charset=utf-8"))).build();
        }
    }
}

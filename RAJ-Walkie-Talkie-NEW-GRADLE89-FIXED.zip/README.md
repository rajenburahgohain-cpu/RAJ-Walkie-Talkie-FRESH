# RAJ Walkie Talkie - New Native Android Build

This package is a fresh native Android/WebRTC project. The GitHub workflow explicitly uses Gradle 8.9 with JDK 17 and builds the APK from this exact ZIP.

Build artifact: `RAJ-Walkie-Talkie-NEW-GRADLE89-debug`

The app uses native Android microphone capture and WebRTC audio rather than WebView getUserMedia. Supabase Realtime is used for signaling.

# RAJ Walkie Talkie — Fresh Android Project

This is a clean restart of the RAJ Walkie Talkie Android project.

## Current foundation
- Native Android wrapper
- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Microphone permission
- Local WebView voice interface
- PTT interface
- GitHub Actions build
- APK artifact upload

## Next phase
Connect Supabase signaling/authentication and WebRTC audio after the clean build succeeds.

## GitHub build
Upload the contents of this project to a new repository (or replace the old project), then open:
Actions → Android Build → Run workflow.

The workflow does not depend on any ZIP file, so the previous missing-ZIP failure is removed.

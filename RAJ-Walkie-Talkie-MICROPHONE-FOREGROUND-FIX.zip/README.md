# RAJ Walkie Talkie — Final WebRTC + Supabase

This Android build uses:
- Supabase Realtime Broadcast for WebRTC signaling
- Browser WebRTC for peer-to-peer audio
- Android microphone permission
- Press-and-hold PTT
- Speaker enable/disable
- Office-code based realtime rooms

The client contains only the Supabase publishable key. No Supabase secret key is included.

Build:
1. GitHub Actions extracts `RAJ-Walkie-Talkie-WEBRTC-SUPABASE.zip`.
2. Gradle 8.9 + JDK 17 builds `app-debug.apk`.


Microphone fix: the app now requests RECORD_AUDIO while visible before starting the microphone foreground service, and explicitly promotes the service with the microphone foreground-service type.

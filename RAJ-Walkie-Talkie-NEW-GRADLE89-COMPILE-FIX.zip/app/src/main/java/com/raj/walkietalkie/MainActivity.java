package com.raj.walkietalkie;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.*;
import org.webrtc.audio.JavaAudioDeviceModule;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import okhttp3.*;

public class MainActivity extends AppCompatActivity {
    private static final String SUPABASE_URL = "https://nxpagmvyoylhtprzccxs.supabase.co";
    private static final String SUPABASE_KEY = "sb_publishable_AT6zontM3G2V3a0dYfzaBQ_nq6K4ozm";
    private static final int MIC_REQ = 71;

    private LinearLayout root, voicePanel;
    private TextView status, codeText, devicesText, connectionText;
    private EditText codeInput;
    private Button joinButton, createButton, leaveButton, speakerButton, pttButton;
    private String roomCode = "";
    private String peerId = UUID.randomUUID().toString().replace("-", "").substring(0, 8);
    private long ref = 0;
    private WebSocket socket;
    private boolean socketJoined = false, micReady = false, speakerOn = true;
    private final OkHttpClient http = new OkHttpClient();
    private final Map<String, PeerConnection> peers = new ConcurrentHashMap<>();
    private final Map<String, IceCandidate> pendingIce = new ConcurrentHashMap<>();
    private PeerConnectionFactory factory;
    private AudioSource audioSource;
    private AudioTrack localAudio;
    private AudioManager audioManager;

    private void ui(Runnable r) { runOnUiThread(r); }
    private TextView tv(String s, int sp) { TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(225,235,250)); t.setPadding(20,16,20,16); return t; }
    private Button btn(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setAllCaps(false); return b; }

    @Override protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,18,37)); getWindow().setNavigationBarColor(Color.rgb(8,18,37));
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        buildUi();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ); else initVoice();
    }

    private void buildUi() {
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(34,22,34,34); root.setBackgroundColor(Color.rgb(7,17,35)); scroll.addView(root); setContentView(scroll);
        TextView title=tv("📻  RAJ Walkie Talkie",32); title.setTypeface(null,1); root.addView(title);
        TextView sub=tv("Private Office Voice • Native Android • Supabase Realtime + WebRTC",16); sub.setTextColor(Color.rgb(160,180,215)); root.addView(sub);
        status=tv("Starting native voice engine…",16); status.setBackgroundColor(Color.rgb(12,27,52)); root.addView(status);
        root.addView(tv("Office",22));
        codeInput=new EditText(this); codeInput.setHint("Enter office code"); codeInput.setTextColor(Color.WHITE); codeInput.setHintTextColor(Color.GRAY); codeInput.setSingleLine(true); root.addView(codeInput);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        createButton=btn("Create Office"); joinButton=btn("Join Office"); row.addView(createButton,new LinearLayout.LayoutParams(0,60,1)); row.addView(joinButton,new LinearLayout.LayoutParams(0,60,1)); root.addView(row);
        codeText=tv("Office code: —",26); codeText.setGravity(Gravity.CENTER); codeText.setBackgroundColor(Color.rgb(10,23,44)); root.addView(codeText);
        voicePanel=new LinearLayout(this); voicePanel.setOrientation(LinearLayout.VERTICAL); voicePanel.setPadding(0,20,0,0); root.addView(voicePanel);
        connectionText=tv("Connection: not joined",16); voicePanel.addView(connectionText);
        speakerButton=btn("🔊 Speaker ON"); voicePanel.addView(speakerButton);
        pttButton=btn("HOLD TO TALK"); pttButton.setTextSize(25); pttButton.setTextColor(Color.WHITE); pttButton.setBackgroundColor(Color.rgb(194,38,30)); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,190); pp.setMargins(0,16,0,16); voicePanel.addView(pttButton,pp);
        devicesText=tv("Audio devices: detecting…",15); voicePanel.addView(devicesText);
        leaveButton=btn("Leave Office"); voicePanel.addView(leaveButton);
        root.addView(tv("Planned product features",21));
        root.addView(tv("• Public / private office channels\n• Group limits and Group Admin controls\n• Free plan + ads / Premium / Business custom plan\n• QR / referral joining\n• Bluetooth audio routing\n• Voice history (Storage + database)\n• STUN + TURN fallback for difficult networks\n• 2G/3G/4G/5G adaptive audio",15));
        createButton.setOnClickListener(v->createOffice()); joinButton.setOnClickListener(v->joinOffice()); leaveButton.setOnClickListener(v->leaveOffice()); speakerButton.setOnClickListener(v->toggleSpeaker());
        pttButton.setOnTouchListener((v,e)->{ if(!micReady) return false; if(e.getAction()==MotionEvent.ACTION_DOWN){ localAudio.setEnabled(true); pttButton.setText("TALKING…"); return true;} if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){ localAudio.setEnabled(false); pttButton.setText("HOLD TO TALK"); return true;} return true; });
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==MIC_REQ){ if(g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) initVoice(); else status.setText("Microphone permission is required for voice."); }}

    private void initVoice(){
        try{
            PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).setEnableInternalTracer(false).createInitializationOptions());
            factory=PeerConnectionFactory.builder().setAudioDeviceModule(JavaAudioDeviceModule.builder(this).setUseHardwareAcousticEchoCanceler(true).setUseHardwareNoiseSuppressor(true).createAudioDeviceModule()).createPeerConnectionFactory();
            audioSource=factory.createAudioSource(new MediaConstraints()); localAudio=factory.createAudioTrack("RAJ_AUDIO",audioSource); localAudio.setEnabled(false); micReady=true;
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION); updateDevices();
            if(Build.VERSION.SDK_INT>=26) startService(new Intent(this,VoiceForegroundService.class));
            status.setText("Native microphone ready • no WebView audio capture");
        }catch(Exception e){ status.setText("Native audio startup error: "+e.getMessage()); }
    }

    private void createOffice(){ String c=generateCode(); codeInput.setText(c); joinRoom(c); }
    private String generateCode(){ return UUID.randomUUID().toString().replace("-","").substring(0,6).toUpperCase(Locale.US); }
    private void joinOffice(){ String c=codeInput.getText().toString().trim().toUpperCase(Locale.US); if(c.length()<4){ status.setText("Enter a valid office code."); return;} joinRoom(c); }

    private void joinRoom(String c){
        if(!micReady){status.setText("Microphone is not ready yet.");return;} leaveSocketOnly(); roomCode=c; codeText.setText("Office code: "+c); status.setText("Connecting to Supabase Realtime…");
        String ws=SUPABASE_URL.replace("https://","wss://")+"/realtime/v1/websocket?apikey="+SUPABASE_KEY+"&vsn=1.0.0";
        Request req=new Request.Builder().url(ws).build(); socket=http.newWebSocket(req,new WebSocketListener(){
            @Override public void onOpen(WebSocket w,Response response){ socket=w; sendJoin(); }
            @Override public void onMessage(WebSocket w,String text){ handleRealtime(text); }
            @Override public void onFailure(WebSocket w,Throwable t,Response r){ ui(()->status.setText("Realtime connection error: "+t.getMessage())); }
            @Override public void onClosed(WebSocket w,int code,String reason){ ui(()->connectionText.setText("Connection closed")); }
        });
    }

    private String topic(){return "realtime:office:"+roomCode;}
    private synchronized String nextRef(){return String.valueOf(++ref);}
    private void sendJoin(){ try{JSONObject p=new JSONObject(); p.put("config",new JSONObject().put("broadcast",new JSONObject().put("ack",false).put("self",false))); JSONObject m=new JSONObject();m.put("topic",topic());m.put("event","phx_join");m.put("payload",p);m.put("ref",nextRef());socket.send(m.toString());}catch(Exception e){ui(()->status.setText("Join error: "+e.getMessage()));}}
    private void broadcast(String event,JSONObject payload){ if(socket==null||!socketJoined)return; try{JSONObject p=new JSONObject();p.put("type","broadcast");p.put("event",event);p.put("payload",payload);JSONObject m=new JSONObject();m.put("topic",topic());m.put("event","broadcast");m.put("payload",p);m.put("ref",nextRef());socket.send(m.toString());}catch(Exception ignored){}}

    private void handleRealtime(String text){ try{JSONObject m=new JSONObject(text); String event=m.optString("event"); String t=m.optString("topic"); if(!topic().equals(t))return; if("phx_reply".equals(event)){socketJoined=true; ui(()->{status.setText("Supabase Realtime connected");connectionText.setText("Connection: online • waiting for devices");}); broadcast("hello",new JSONObject().put("peerId",peerId)); return;} if("broadcast".equals(event)){JSONObject p=m.optJSONObject("payload"); if(p==null)return; String ev=p.optString("event"); JSONObject data=p.optJSONObject("payload"); if(data!=null)handleSignal(ev,data);} }catch(Exception ignored){} }

    private void handleSignal(String ev,JSONObject d){ String from=d.optString("from"); if(from.isEmpty()||from.equals(peerId))return; try{ if("hello".equals(ev)){ if(peerId.compareTo(from)<0) createOffer(from); } else if("offer".equals(ev)&&peerId.equals(d.optString("to"))){ handleOffer(from,d.getString("sdp")); } else if("answer".equals(ev)&&peerId.equals(d.optString("to"))){ handleAnswer(from,d.getString("sdp")); } else if("ice".equals(ev)&&peerId.equals(d.optString("to"))){ addIce(from,d.getString("candidate"),d.getInt("sdpMLineIndex"),d.getString("sdpMid")); } else if("bye".equals(ev)){ removePeer(from); } }catch(Exception ignored){} }

    private PeerConnection newPeer(String id){
        if(peers.containsKey(id))return peers.get(id);
        PeerConnection.RTCConfiguration cfg=new PeerConnection.RTCConfiguration(Collections.singletonList(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()));
        cfg.sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN;
        PeerConnection pc=factory.createPeerConnection(cfg,new PeerConnection.Observer(){
            public void onSignalingChange(PeerConnection.SignalingState s){} public void onIceConnectionChange(PeerConnection.IceConnectionState s){ui(()->connectionText.setText("Connection: "+s.name()+" • devices: "+peers.size())); if(s==PeerConnection.IceConnectionState.FAILED||s==PeerConnection.IceConnectionState.CLOSED)removePeer(id);}
            public void onIceConnectionReceivingChange(boolean b){} public void onIceGatheringChange(PeerConnection.IceGatheringState s){} public void onIceCandidate(IceCandidate c){try{broadcast("ice",new JSONObject().put("from",peerId).put("to",id).put("candidate",c.sdp).put("sdpMLineIndex",c.sdpMLineIndex).put("sdpMid",c.sdpMid));}catch(Exception ignored){}}
            public void onIceCandidatesRemoved(IceCandidate[] c){} public void onAddStream(MediaStream s){} public void onRemoveStream(MediaStream s){} public void onDataChannel(DataChannel d){} public void onRenegotiationNeeded(){} public void onAddTrack(RtpReceiver r,MediaStream[] ms){ if(r.track() instanceof AudioTrack){((AudioTrack)r.track()).setEnabled(true);}}
        });
        if(pc!=null){ pc.addTrack(localAudio); peers.put(id,pc); }
        return pc;
    }

    private void createOffer(String id){ PeerConnection pc=newPeer(id); if(pc==null)return; pc.createOffer(new SimpleSdp(){public void onCreateSuccess(SessionDescription s){pc.setLocalDescription(new SimpleSdp(){public void onSetSuccess(){try{broadcast("offer",new JSONObject().put("from",peerId).put("to",id).put("sdp",s.description));}catch(Exception ignored){}}},s);}},new MediaConstraints()); }
    private void handleOffer(String id,String sdp){ PeerConnection pc=newPeer(id); if(pc==null)return; pc.setRemoteDescription(new SimpleSdp(){public void onSetSuccess(){pc.createAnswer(new SimpleSdp(){public void onCreateSuccess(SessionDescription a){pc.setLocalDescription(new SimpleSdp(){public void onSetSuccess(){try{broadcast("answer",new JSONObject().put("from",peerId).put("to",id).put("sdp",a.description));}catch(Exception ignored){}}},a);}},new MediaConstraints());}},new SessionDescription(SessionDescription.Type.OFFER,sdp)); }
    private void handleAnswer(String id,String sdp){PeerConnection pc=peers.get(id);if(pc!=null)pc.setRemoteDescription(new SimpleSdp(),new SessionDescription(SessionDescription.Type.ANSWER,sdp));}
    private void addIce(String id,String c,int idx,String mid){PeerConnection pc=newPeer(id);if(pc!=null)pc.addIceCandidate(new IceCandidate(mid,idx,c));}
    private void removePeer(String id){PeerConnection p=peers.remove(id);if(p!=null){p.close();p.dispose();}ui(()->connectionText.setText("Connection: "+(socketJoined?"online":"offline")+" • devices: "+peers.size()));}

    private void toggleSpeaker(){speakerOn=!speakerOn; if(Build.VERSION.SDK_INT>=31){AudioDeviceInfo target=null; for(AudioDeviceInfo d:audioManager.getAvailableCommunicationDevices()){if(speakerOn&&d.getType()==AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)target=d; if(!speakerOn&&(d.getType()==AudioDeviceInfo.TYPE_BLUETOOTH_A2DP||d.getType()==AudioDeviceInfo.TYPE_BLUETOOTH_SCO))target=d;} if(target!=null)audioManager.setCommunicationDevice(target); else audioManager.clearCommunicationDevice();}else audioManager.setSpeakerphoneOn(speakerOn); speakerButton.setText(speakerOn?"🔊 Speaker ON":"🎧 Speaker / Bluetooth"); updateDevices();}
    private void updateDevices(){if(audioManager==null)return; StringBuilder s=new StringBuilder("Audio devices: "); if(Build.VERSION.SDK_INT>=23){AudioDeviceInfo[] ins=audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS),outs=audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);s.append("inputs ").append(ins.length).append(" • outputs ").append(outs.length);} devicesText.setText(s.toString());}

    private void leaveSocketOnly(){socketJoined=false;if(socket!=null){try{socket.close(1000,"switch room");}catch(Exception ignored){}socket=null;} for(String id:new ArrayList<>(peers.keySet()))removePeer(id);}
    private void leaveOffice(){ if(socketJoined){broadcast("bye",new JSONObject().put("from",peerId));} leaveSocketOnly(); codeText.setText("Office code: —"); connectionText.setText("Connection: not joined"); status.setText("Left office"); }
    @Override protected void onDestroy(){leaveSocketOnly();if(localAudio!=null)localAudio.dispose();if(audioSource!=null)audioSource.dispose();if(factory!=null)factory.dispose();http.dispatcher().executorService().shutdown();super.onDestroy();}

    private static class SimpleSdp implements SdpObserver{public void onCreateSuccess(SessionDescription s){}public void onSetSuccess(){}public void onCreateFailure(String s){}public void onSetFailure(String s){}}
}

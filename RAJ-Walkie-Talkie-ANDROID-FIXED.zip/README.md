# RAJ Walkie Talkie — Android Fixed Build

This package is the Android WebView/WebRTC build for RAJ Walkie Talkie.

Fixes included:
- Secure `WebViewAssetLoader` origin for local HTML.
- Android runtime microphone permission handling.
- WebView audio-capture permission handling with pending-request retry.
- Trusted-origin check before granting microphone access.
- Communication audio mode.
- Foreground voice service.
- Existing Supabase Realtime + WebRTC voice UI.

Build:
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- compileSdk 35
- targetSdk 35

Important: the ZIP filename is intentionally simple. The GitHub workflow is configured to use the same filename.

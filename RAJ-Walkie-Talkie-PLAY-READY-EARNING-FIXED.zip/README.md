# RAJ Walkie Talkie — Play-ready Auth + Billing + Ads

This package is prepared for Google Play release with:

- Supabase email/password sign-up, login, password reset and session persistence.
- Native WebRTC push-to-talk voice.
- Android microphone foreground service for minimized voice sessions.
- Realtime reconnect support.
- Free plan with Google Mobile Ads banner integration.
- Premium subscription: **₹49/month** via Google Play Billing.
- Business / Custom plan: **₹289/month** via Google Play Billing.
- Google Play Billing Library **9.1.0**.
- Android target API **36** for the current Google Play requirement.
- Privacy policy HTML included.

## Important: items that must be completed in your own Google accounts

### 1. Google Play Console subscriptions
Create these subscription products and activate their monthly base plans:

- Product ID: `raj_premium_monthly` — ₹49/month
- Product ID: `raj_business_monthly` — ₹289/month

The app already queries both IDs and opens Google Play Billing. Prices are controlled by Play Console; do not hard-code a different production price.

### 2. AdMob
The project currently uses **Google test App ID and test banner unit ID** so the app can be tested safely. Test ads do not generate revenue. Before production, create your AdMob app/ad unit and replace:

- Manifest App ID: `ca-app-pub-3940256099942544~3347511713`
- Banner test ID: `ca-app-pub-3940256099942544/6300978111`

with your real AdMob IDs. The Free plan then shows the banner; Premium hides it.

### 3. Privacy policy
`privacy-policy.html` is included. Publish it at a stable HTTPS URL (for example, your GitHub Pages site) and enter that URL in Play Console.

### 4. Play Console declarations
You still must complete the Play Console forms yourself: Data safety, content rating, target audience, ads declaration, app access/login instructions, privacy policy, store listing, screenshots, and any permission declarations requested by Play Console. These cannot be completed from source code alone.

### 5. Production billing security
The Android client acknowledges purchases and restores active subscriptions. For a production entitlement system, verify Google Play purchase tokens on a secure backend and bind the entitlement to the authenticated Supabase user. Never put Google service-account credentials in the APK.

### 6. Signing
Build the final release **AAB** with your own upload/release key. Do not publish a debug APK.

## Business / Custom note
Because this is a digital service used inside the app, an in-app ₹289 subscription is implemented through Google Play Billing. A variable external “custom payment” flow should not be used as a substitute for Play Billing for digital in-app access. If you need different Business prices, create separate Play subscription products/base plans as appropriate.

## Current SDK configuration
- compileSdk 36
- targetSdk 36
- minSdk 23
- Play Billing 9.1.0
- Google Mobile Ads SDK 25.4.0

## Build note
The source package has been prepared, but this environment does not contain the Gradle executable/Android build toolchain, so a successful local APK/AAB compilation could not be independently verified here.

package com.raj.walkietalkie;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;
import org.webrtc.*;
import org.webrtc.audio.JavaAudioDeviceModule;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import okhttp3.*;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.admanager.AdManagerAdRequest;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.UserMessagingPlatform;

public class MainActivity extends AppCompatActivity {
    private static final String SUPABASE_URL = "https://nxpagmvyoylhtprzccxs.supabase.co";
    private static final String SUPABASE_KEY = "sb_publishable_AT6zontM3G2V3a0dYfzaBQ_nq6K4ozm";
    private static final int MIC_REQ = 71;

    private LinearLayout root, authPanel, appPanel, voicePanel;
    private TextView status, codeText, devicesText, connectionText, authStatus, premiumStatus;
    private EditText emailInput, passwordInput, codeInput;
    private Button loginButton, signupButton, resetButton, logoutButton, joinButton, createButton, leaveButton, speakerButton, pttButton, premiumButton, businessButton;
    private AdView bannerAd;
    private ConsentInformation consentInformation;
    private String roomCode = "";
    private final String peerId = UUID.randomUUID().toString().replace("-", "").substring(0, 8);
    private long ref = 0;
    private WebSocket socket;
    private boolean socketJoined = false, micReady = false, speakerOn = true;
    private final OkHttpClient http = new OkHttpClient();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, PeerConnection> peers = new ConcurrentHashMap<>();
    private PeerConnectionFactory factory;
    private AudioSource audioSource;
    private AudioTrack localAudio;
    private AudioManager audioManager;
    private AuthManager auth;
    private PlayBillingManager billing;
    private boolean reconnectScheduled = false;

    private void ui(Runnable r) { runOnUiThread(r); }
    private TextView tv(String s, int sp) { TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(225,235,250)); t.setPadding(20,16,20,16); return t; }
    private Button btn(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setAllCaps(false); return b; }

    @Override protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,18,37));
        getWindow().setNavigationBarColor(Color.rgb(8,18,37));
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        auth=new AuthManager(this,SUPABASE_URL,SUPABASE_KEY);
        billing=new PlayBillingManager(this,(message,premium)->ui(()->{
            premiumStatus.setText("⭐ Premium: "+(premium?"ACTIVE":"Not active")+"\n"+message);
            premiumButton.setText(premium?"Premium Active":"Upgrade Premium ₹49/month");
            if (bannerAd != null) { bannerAd.setVisibility(premium ? android.view.View.GONE : android.view.View.VISIBLE); if (!premium && bannerAd.getAdSize()!=null && consentInformation!=null && consentInformation.canRequestAds()) bannerAd.loadAd(new AdRequest.Builder().build()); }
        }));
        buildUi();
        requestConsentAndInitAds();
        updateAuthUi();
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ);
        else initVoice();
    }

    private void buildUi() {
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,18,28,34); root.setBackgroundColor(Color.rgb(7,17,35)); scroll.addView(root); setContentView(scroll);

        TextView title=tv("📻  RAJ Walkie Talkie",30); title.setTypeface(null,1); root.addView(title);
        root.addView(tv("Private Office Voice • Native Android • Supabase Realtime + WebRTC",15));

        authPanel=new LinearLayout(this); authPanel.setOrientation(LinearLayout.VERTICAL); authPanel.setPadding(0,12,0,12); root.addView(authPanel);
        authPanel.addView(tv("🔐 Account Login",22));
        emailInput=new EditText(this); emailInput.setHint("Email"); emailInput.setTextColor(Color.WHITE); emailInput.setHintTextColor(Color.GRAY); emailInput.setSingleLine(true); emailInput.setInputType(33); authPanel.addView(emailInput);
        passwordInput=new EditText(this); passwordInput.setHint("Password"); passwordInput.setTextColor(Color.WHITE); passwordInput.setHintTextColor(Color.GRAY); passwordInput.setSingleLine(true); passwordInput.setInputType(129); authPanel.addView(passwordInput);
        LinearLayout ar=new LinearLayout(this); ar.setOrientation(LinearLayout.HORIZONTAL);
        loginButton=btn("Login"); signupButton=btn("Create Account"); ar.addView(loginButton,new LinearLayout.LayoutParams(0,60,1)); ar.addView(signupButton,new LinearLayout.LayoutParams(0,60,1)); authPanel.addView(ar);
        resetButton=btn("Forgot password / Send reset email"); authPanel.addView(resetButton);
        authStatus=tv("Not signed in",14); authStatus.setBackgroundColor(Color.rgb(12,27,52)); authPanel.addView(authStatus);

        appPanel=new LinearLayout(this); appPanel.setOrientation(LinearLayout.VERTICAL); root.addView(appPanel);
        status=tv("Starting native voice engine…",16); status.setBackgroundColor(Color.rgb(12,27,52)); appPanel.addView(status);
        TextView account=tv("Account",19); appPanel.addView(account);
        logoutButton=btn("Sign out"); appPanel.addView(logoutButton);

        appPanel.addView(tv("Office",22));
        codeInput=new EditText(this); codeInput.setHint("Enter office code"); codeInput.setTextColor(Color.WHITE); codeInput.setHintTextColor(Color.GRAY); codeInput.setSingleLine(true); appPanel.addView(codeInput);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        createButton=btn("Create Office"); joinButton=btn("Join Office"); row.addView(createButton,new LinearLayout.LayoutParams(0,60,1)); row.addView(joinButton,new LinearLayout.LayoutParams(0,60,1)); appPanel.addView(row);
        codeText=tv("Office code: —",24); codeText.setGravity(Gravity.CENTER); codeText.setBackgroundColor(Color.rgb(10,23,44)); appPanel.addView(codeText);

        LinearLayout premium=new LinearLayout(this); premium.setOrientation(LinearLayout.VERTICAL); premium.setPadding(0,18,0,10); appPanel.addView(premium);
        premium.addView(tv("💰 Earning & Plans",22));
        premiumStatus=tv("⭐ Premium: checking Google Play…",14); premiumStatus.setBackgroundColor(Color.rgb(12,27,52)); premium.addView(premiumStatus);
        premiumButton=btn("Upgrade Premium ₹49/month"); premium.addView(premiumButton);
        businessButton=btn("Business / Custom ₹289/month"); premium.addView(businessButton);
        bannerAd=new AdView(this); bannerAd.setAdSize(com.google.android.gms.ads.AdSize.BANNER); bannerAd.setAdUnitId("ca-app-pub-3940256099942544/6300978111"); premium.addView(bannerAd);

        voicePanel=new LinearLayout(this); voicePanel.setOrientation(LinearLayout.VERTICAL); voicePanel.setPadding(0,20,0,0); appPanel.addView(voicePanel);
        connectionText=tv("Connection: not joined",16); voicePanel.addView(connectionText);
        speakerButton=btn("🔊 Speaker ON"); voicePanel.addView(speakerButton);
        pttButton=btn("HOLD TO TALK"); pttButton.setTextSize(25); pttButton.setTextColor(Color.WHITE); pttButton.setBackgroundColor(Color.rgb(194,38,30)); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,190); pp.setMargins(0,16,0,16); voicePanel.addView(pttButton,pp);
        devicesText=tv("Audio devices: detecting…",15); voicePanel.addView(devicesText);
        leaveButton=btn("Leave Office"); voicePanel.addView(leaveButton);
        appPanel.addView(tv("Features",21));
        appPanel.addView(tv("• Email/password authentication\n• Supabase Realtime signaling\n• WebRTC push-to-talk voice\n• Foreground service for minimized voice sessions\n• Free plan + AdMob ads\n• Premium ₹49/month via Google Play Billing\n• Business / Custom ₹289/month via Google Play Billing\n• Bluetooth / speaker routing",15));

        loginButton.setOnClickListener(v->login());
        signupButton.setOnClickListener(v->signup());
        resetButton.setOnClickListener(v->resetPassword());
        logoutButton.setOnClickListener(v->logout());
        premiumButton.setOnClickListener(v->{ if(auth.isLoggedIn()) billing.launchPremium(this); else authStatus.setText("Login first to purchase Premium."); });
        businessButton.setOnClickListener(v->{ if(auth.isLoggedIn()) billing.launchBusiness(this); else authStatus.setText("Login first to choose Business."); });
        createButton.setOnClickListener(v->createOffice());
        joinButton.setOnClickListener(v->joinOffice());
        leaveButton.setOnClickListener(v->leaveOffice());
        speakerButton.setOnClickListener(v->toggleSpeaker());
        pttButton.setOnTouchListener((v,e)->{
            if(!micReady || !socketJoined || localAudio==null) return false;
            if(e.getAction()==MotionEvent.ACTION_DOWN){ localAudio.setEnabled(true); pttButton.setText("TALKING…"); broadcast("ptt-start",new JSONObjectSafe().put("from",peerId).obj()); return true; }
            if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL){ localAudio.setEnabled(false); pttButton.setText("HOLD TO TALK"); broadcast("ptt-stop",new JSONObjectSafe().put("from",peerId).obj()); return true; }
            return true;
        });
    }

    private void requestConsentAndInitAds(){
        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        UserMessagingPlatform.loadAndShowConsentFormIfRequired(this, formError -> {
            if (formError == null || consentInformation.canRequestAds()) {
                MobileAds.initialize(this, status -> loadFreeAd());
            }
        });
        if (consentInformation.canRequestAds()) {
            MobileAds.initialize(this, status -> loadFreeAd());
        }
    }

    private void loadFreeAd(){
        if (bannerAd == null) return;
        bannerAd.setVisibility(billing != null && billing.isPremiumActive() ? android.view.View.GONE : android.view.View.VISIBLE);
        if (bannerAd.getVisibility() == android.view.View.VISIBLE) bannerAd.loadAd(new AdRequest.Builder().build());
    }

    private void updateAuthUi(){
        boolean logged=auth.isLoggedIn();
        authPanel.setVisibility(logged?LinearLayout.GONE:LinearLayout.VISIBLE);
        appPanel.setVisibility(logged?LinearLayout.VISIBLE:LinearLayout.GONE);
        if(logged){ authStatus.setText("Signed in: "+auth.getEmail()); billing.connect(); }
    }

    private void login(){
        String email=emailInput.getText().toString().trim(); String pass=passwordInput.getText().toString();
        if(email.isEmpty()||pass.isEmpty()){authStatus.setText("Enter email and password.");return;}
        authStatus.setText("Signing in…");
        auth.signIn(email,pass,new Callback(){
            @Override public void onFailure(Call call,java.io.IOException e){ui(()->authStatus.setText("Login error: "+e.getMessage()));}
            @Override public void onResponse(Call call,Response r)throws java.io.IOException{String body=r.body()==null?"":r.body().string(); boolean ok=r.isSuccessful(); r.close(); ui(()->{authStatus.setText(ok?"Login successful":"Login failed: "+extractError(body)); if(ok) updateAuthUi();});}
        });
    }

    private void signup(){
        String email=emailInput.getText().toString().trim(); String pass=passwordInput.getText().toString();
        if(email.isEmpty()||pass.length()<6){authStatus.setText("Use a valid email and a password of at least 6 characters.");return;}
        authStatus.setText("Creating account…");
        auth.signUp(email,pass,new Callback(){
            @Override public void onFailure(Call call,java.io.IOException e){ui(()->authStatus.setText("Signup error: "+e.getMessage()));}
            @Override public void onResponse(Call call,Response r)throws java.io.IOException{String body=r.body()==null?"":r.body().string(); boolean ok=r.isSuccessful(); r.close(); ui(()->authStatus.setText(ok?"Account created. Check email if confirmation is enabled, then Login.":"Signup failed: "+extractError(body)));}
        });
    }

    private void resetPassword(){
        String email=emailInput.getText().toString().trim(); if(email.isEmpty()){authStatus.setText("Enter your email first.");return;}
        authStatus.setText("Sending password reset email…");
        auth.resetPassword(email,new Callback(){
            @Override public void onFailure(Call call,java.io.IOException e){ui(()->authStatus.setText("Reset error: "+e.getMessage()));}
            @Override public void onResponse(Call call,Response r)throws java.io.IOException{boolean ok=r.isSuccessful();r.close();ui(()->authStatus.setText(ok?"Password reset email requested.":"Reset request failed."));}
        });
    }

    private void logout(){
        leaveSocketOnly();
        try{stopService(new Intent(this,VoiceForegroundService.class));}catch(Exception ignored){}
        auth.signOut();
        authStatus.setText("Signed out");
        updateAuthUi();
    }

    private String extractError(String body){ try{JSONObject o=new JSONObject(body); String m=o.optString("msg",""); if(m.isEmpty())m=o.optString("error_description",""); if(m.isEmpty())m=o.optString("message",""); return m.isEmpty()?body:m;}catch(Exception e){return body;} }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==MIC_REQ){ if(g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) initVoice(); else status.setText("Microphone permission is required for voice."); }}

    private void initVoice(){
        try{
            PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).setEnableInternalTracer(false).createInitializationOptions());
            factory=PeerConnectionFactory.builder().setAudioDeviceModule(JavaAudioDeviceModule.builder(this).setUseHardwareAcousticEchoCanceler(true).setUseHardwareNoiseSuppressor(true).createAudioDeviceModule()).createPeerConnectionFactory();
            audioSource=factory.createAudioSource(new MediaConstraints()); localAudio=factory.createAudioTrack("RAJ_AUDIO",audioSource); localAudio.setEnabled(false); micReady=true;
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION); updateDevices();
            if(Build.VERSION.SDK_INT>=26) startForegroundService(new Intent(this,VoiceForegroundService.class));
            status.setText("Native microphone ready • Foreground voice service enabled");
        }catch(Exception e){ status.setText("Native audio startup error: "+e.getMessage()); }
    }

    private void createOffice(){ String c=generateCode(); codeInput.setText(c); joinRoom(c); }
    private String generateCode(){ return UUID.randomUUID().toString().replace("-","").substring(0,6).toUpperCase(Locale.US); }
    private void joinOffice(){ String c=codeInput.getText().toString().trim().toUpperCase(Locale.US); if(c.length()<4){ status.setText("Enter a valid office code."); return;} joinRoom(c); }

    private void joinRoom(String c){
        if(!auth.isLoggedIn()){status.setText("Login required before joining an office.");return;}
        if(!micReady){status.setText("Microphone is not ready yet.");return;}
        leaveSocketOnly(); roomCode=c; codeText.setText("Office code: "+c); status.setText("Connecting to Supabase Realtime…");
        String ws=SUPABASE_URL.replace("https://","wss://")+"/realtime/v1/websocket?apikey="+SUPABASE_KEY+"&vsn=1.0.0";
        Request req=new Request.Builder().url(ws).build(); socket=http.newWebSocket(req,new WebSocketListener(){
            @Override public void onOpen(WebSocket w,Response response){ socket=w; reconnectScheduled=false; sendJoin(); }
            @Override public void onMessage(WebSocket w,String text){ handleRealtime(text); }
            @Override public void onFailure(WebSocket w,Throwable t,Response r){ ui(()->{status.setText("Realtime connection error; reconnecting…");scheduleReconnect();}); }
            @Override public void onClosed(WebSocket w,int code,String reason){ ui(()->{connectionText.setText("Connection closed • reconnecting…");scheduleReconnect();}); }
        });
    }

    private void scheduleReconnect(){
        if(reconnectScheduled || roomCode.isEmpty() || !auth.isLoggedIn())return;
        reconnectScheduled=true;
        handler.postDelayed(()->{reconnectScheduled=false;if(!roomCode.isEmpty()&&auth.isLoggedIn())joinRoom(roomCode);},3000);
    }

    private String topic(){return "realtime:office:"+roomCode;}
    private synchronized String nextRef(){return String.valueOf(++ref);}
    private void sendJoin(){ try{JSONObject p=new JSONObject(); p.put("config",new JSONObject().put("broadcast",new JSONObject().put("ack",false).put("self",false))); String token=auth.getAccessToken(); if(!token.isEmpty())p.put("access_token",token); JSONObject m=new JSONObject();m.put("topic",topic());m.put("event","phx_join");m.put("payload",p);m.put("ref",nextRef());socket.send(m.toString());}catch(Exception e){ui(()->status.setText("Join error: "+e.getMessage()));}}
    private void broadcast(String event,JSONObject payload){ if(socket==null||!socketJoined)return; try{JSONObject p=new JSONObject();p.put("type","broadcast");p.put("event",event);p.put("payload",payload);JSONObject m=new JSONObject();m.put("topic",topic());m.put("event","broadcast");m.put("payload",p);m.put("ref",nextRef());socket.send(m.toString());}catch(Exception ignored){}}

    private void handleRealtime(String text){ try{JSONObject m=new JSONObject(text); String event=m.optString("event"); String t=m.optString("topic"); if(!topic().equals(t))return; if("phx_reply".equals(event)){socketJoined=true; ui(()->{status.setText("Supabase Realtime connected");connectionText.setText("Connection: online • waiting for devices");}); broadcast("hello",new JSONObjectSafe().put("peerId",peerId).obj()); return;} if("broadcast".equals(event)){JSONObject p=m.optJSONObject("payload"); if(p==null)return; String ev=p.optString("event"); JSONObject data=p.optJSONObject("payload"); if(data!=null)handleSignal(ev,data);} }catch(Exception ignored){}}

    private void handleSignal(String ev,JSONObject d){ String from=d.optString("from"); if(from.isEmpty()||from.equals(peerId))return; try{ if("hello".equals(ev)){ if(peerId.compareTo(from)<0) createOffer(from); } else if("offer".equals(ev)&&peerId.equals(d.optString("to"))){ handleOffer(from,d.getString("sdp")); } else if("answer".equals(ev)&&peerId.equals(d.optString("to"))){ handleAnswer(from,d.getString("sdp")); } else if("ice".equals(ev)&&peerId.equals(d.optString("to"))){ addIce(from,d.getString("candidate"),d.getInt("sdpMLineIndex"),d.getString("sdpMid")); } else if("bye".equals(ev)){ removePeer(from); } }catch(Exception ignored){}}

    private PeerConnection newPeer(String id){
        if(peers.containsKey(id))return peers.get(id);
        PeerConnection.RTCConfiguration cfg=new PeerConnection.RTCConfiguration(Collections.singletonList(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())); cfg.sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN;
        PeerConnection pc=factory.createPeerConnection(cfg,new PeerConnection.Observer(){
            public void onSignalingChange(PeerConnection.SignalingState s){} public void onIceConnectionChange(PeerConnection.IceConnectionState s){ui(()->connectionText.setText("Connection: "+s.name()+" • devices: "+peers.size())); if(s==PeerConnection.IceConnectionState.FAILED||s==PeerConnection.IceConnectionState.CLOSED)removePeer(id);} public void onIceConnectionReceivingChange(boolean b){} public void onIceGatheringChange(PeerConnection.IceGatheringState s){} public void onIceCandidate(IceCandidate c){try{broadcast("ice",new JSONObjectSafe().put("from",peerId).put("to",id).put("candidate",c.sdp).put("sdpMLineIndex",c.sdpMLineIndex).put("sdpMid",c.sdpMid).obj());}catch(Exception ignored){}} public void onIceCandidatesRemoved(IceCandidate[] c){} public void onAddStream(MediaStream s){} public void onRemoveStream(MediaStream s){} public void onDataChannel(DataChannel d){} public void onRenegotiationNeeded(){} public void onAddTrack(RtpReceiver r,MediaStream[] ms){ if(r.track() instanceof AudioTrack)((AudioTrack)r.track()).setEnabled(true); }
        });
        if(pc!=null){ pc.addTrack(localAudio); peers.put(id,pc); } return pc;
    }

    private void createOffer(String id){ PeerConnection pc=newPeer(id); if(pc==null)return; pc.createOffer(new SimpleSdp(){public void onCreateSuccess(SessionDescription s){pc.setLocalDescription(new SimpleSdp(){public void onSetSuccess(){broadcast("offer",new JSONObjectSafe().put("from",peerId).put("to",id).put("sdp",s.description).obj());}},s);}},new MediaConstraints()); }
    private void handleOffer(String id,String sdp){ PeerConnection pc=newPeer(id); if(pc==null)return; pc.setRemoteDescription(new SimpleSdp(){public void onSetSuccess(){pc.createAnswer(new SimpleSdp(){public void onCreateSuccess(SessionDescription a){pc.setLocalDescription(new SimpleSdp(){public void onSetSuccess(){broadcast("answer",new JSONObjectSafe().put("from",peerId).put("to",id).put("sdp",a.description).obj());}},a);}},new MediaConstraints());}},new SessionDescription(SessionDescription.Type.OFFER,sdp)); }
    private void handleAnswer(String id,String sdp){PeerConnection pc=peers.get(id);if(pc!=null)pc.setRemoteDescription(new SimpleSdp(),new SessionDescription(SessionDescription.Type.ANSWER,sdp));}
    private void addIce(String id,String c,int idx,String mid){PeerConnection pc=newPeer(id);if(pc!=null)pc.addIceCandidate(new IceCandidate(mid,idx,c));}
    private void removePeer(String id){PeerConnection p=peers.remove(id);if(p!=null){p.close();p.dispose();}ui(()->connectionText.setText("Connection: "+(socketJoined?"online":"offline")+" • devices: "+peers.size()));}

    private void toggleSpeaker(){speakerOn=!speakerOn; if(Build.VERSION.SDK_INT>=31){AudioDeviceInfo target=null; for(AudioDeviceInfo d:audioManager.getAvailableCommunicationDevices()){if(speakerOn&&d.getType()==AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)target=d; if(!speakerOn&&(d.getType()==AudioDeviceInfo.TYPE_BLUETOOTH_A2DP||d.getType()==AudioDeviceInfo.TYPE_BLUETOOTH_SCO) )target=d;} if(target!=null)audioManager.setCommunicationDevice(target); else audioManager.clearCommunicationDevice();}else audioManager.setSpeakerphoneOn(speakerOn); speakerButton.setText(speakerOn?"🔊 Speaker ON":"🎧 Speaker / Bluetooth"); updateDevices();}
    private void updateDevices(){if(audioManager==null)return; StringBuilder s=new StringBuilder("Audio devices: "); if(Build.VERSION.SDK_INT>=23){AudioDeviceInfo[] ins=audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS),outs=audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS);s.append("inputs ").append(ins.length).append(" • outputs ").append(outs.length);} devicesText.setText(s.toString());}

    private void leaveSocketOnly(){socketJoined=false;if(socket!=null){try{socket.close(1000,"switch room");}catch(Exception ignored){}socket=null;} for(String id:new ArrayList<>(peers.keySet()))removePeer(id);}
    private void leaveOffice(){ if(socketJoined)broadcast("bye",new JSONObjectSafe().put("from",peerId).obj()); leaveSocketOnly(); try{stopService(new Intent(this,VoiceForegroundService.class));}catch(Exception ignored){} codeText.setText("Office code: —"); connectionText.setText("Connection: not joined"); status.setText("Left office"); }

    @Override protected void onResume(){super.onResume();if(auth!=null&&auth.isLoggedIn()&&billing!=null)billing.connect();}
    @Override protected void onDestroy(){leaveSocketOnly();if(billing!=null)billing.destroy();if(localAudio!=null)localAudio.dispose();if(audioSource!=null)audioSource.dispose();if(factory!=null)factory.dispose();http.dispatcher().executorService().shutdown();super.onDestroy();}

    private static class SimpleSdp implements SdpObserver{public void onCreateSuccess(SessionDescription s){}public void onSetSuccess(){}public void onCreateFailure(String s){}public void onSetFailure(String s){}}
    private static class JSONObjectSafe { private final JSONObject o=new JSONObject(); JSONObjectSafe put(String k,Object v){try{o.put(k,v);}catch(Exception ignored){}return this;} JSONObject obj(){return o;} }
}

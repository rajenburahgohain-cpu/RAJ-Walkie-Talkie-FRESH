package com.raj.walkietalkie;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.android.billingclient.api.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlayBillingManager implements PurchasesUpdatedListener {
    public static final String PREMIUM_PRODUCT_ID = "raj_premium_monthly";
    public static final String BUSINESS_PRODUCT_ID = "raj_business_monthly";
    private static final String PREFS = "raj_billing";
    private static final String PREMIUM = "premium_active";
    private static final String BUSINESS = "business_active";

    public interface Listener { void onBillingState(String message, boolean premiumActive); }

    private final Context context;
    private final Listener listener;
    private final SharedPreferences prefs;
    private BillingClient billingClient;
    private final Map<String, ProductDetails> products = new HashMap<>();

    public PlayBillingManager(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        billingClient = BillingClient.newBuilder(this.context)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
    }

    public boolean isPremiumActive() { return prefs.getBoolean(PREMIUM, false); }
    public boolean isBusinessActive() { return prefs.getBoolean(BUSINESS, false); }

    public void connect() {
        if (billingClient.isReady()) { queryProducts(); queryActiveSubscriptions(); return; }
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    listener.onBillingState("Google Play Billing connected", isPremiumActive());
                    queryProducts();
                    queryActiveSubscriptions();
                } else listener.onBillingState("Billing unavailable: " + result.getDebugMessage(), isPremiumActive());
            }
            @Override public void onBillingServiceDisconnected() {
                listener.onBillingState("Google Play Billing disconnected; retrying automatically", isPremiumActive());
            }
        });
    }

    private void queryProducts() {
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(Arrays.asList(
                        QueryProductDetailsParams.Product.newBuilder().setProductId(PREMIUM_PRODUCT_ID).setProductType(BillingClient.ProductType.SUBS).build(),
                        QueryProductDetailsParams.Product.newBuilder().setProductId(BUSINESS_PRODUCT_ID).setProductType(BillingClient.ProductType.SUBS).build()))
                .build();
        billingClient.queryProductDetailsAsync(params, (result, details) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && details != null) {
                products.clear();
                for (ProductDetails d : details.getProductDetailsList()) products.put(d.getProductId(), d);
                listener.onBillingState("Plans loaded from Google Play", isPremiumActive());
            } else {
                listener.onBillingState("Create Play Console products: " + PREMIUM_PRODUCT_ID + " and " + BUSINESS_PRODUCT_ID, isPremiumActive());
            }
        });
    }

    public void launchPremium(Activity activity) { launchSubscription(activity, PREMIUM_PRODUCT_ID, "Premium"); }
    public void launchBusiness(Activity activity) { launchSubscription(activity, BUSINESS_PRODUCT_ID, "Business / Custom"); }

    private void launchSubscription(Activity activity, String productId, String label) {
        ProductDetails product = products.get(productId);
        if (product == null) { listener.onBillingState(label + " product is not loaded. Check Google Play configuration.", isPremiumActive()); queryProducts(); return; }
        List<ProductDetails.SubscriptionOfferDetails> offers = product.getSubscriptionOfferDetails();
        if (offers == null || offers.isEmpty()) { listener.onBillingState("No eligible " + label + " offer is available for this Google Play account.", isPremiumActive()); return; }
        String offerToken = offers.get(0).getOfferToken();
        BillingFlowParams.ProductDetailsParams pp = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(product).setOfferToken(offerToken).build();
        BillingFlowParams flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(pp)).build();
        BillingResult result = billingClient.launchBillingFlow(activity, flow);
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK)
            listener.onBillingState("Could not open Google Play Billing: " + result.getDebugMessage(), isPremiumActive());
    }

    private void queryActiveSubscriptions() {
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build();
        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
            boolean premium = false, business = false;
            for (Purchase purchase : purchases) {
                if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    if (purchase.getProducts().contains(PREMIUM_PRODUCT_ID)) premium = true;
                    if (purchase.getProducts().contains(BUSINESS_PRODUCT_ID)) business = true;
                    processPurchase(purchase);
                }
            }
            prefs.edit().putBoolean(PREMIUM, premium).putBoolean(BUSINESS, business).apply();
            listener.onBillingState(premium ? "Premium active" : (business ? "Business active" : "No paid plan active"), premium);
        });
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) processPurchase(purchase);
        } else if (result.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
            listener.onBillingState("Google Play purchase canceled", isPremiumActive());
        } else if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            listener.onBillingState("Google Play billing error: " + result.getDebugMessage(), isPremiumActive());
        }
    }

    private void processPurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) {
            listener.onBillingState("Purchase pending; access will activate after Google confirms payment.", isPremiumActive());
            return;
        }
        boolean premium = purchase.getProducts().contains(PREMIUM_PRODUCT_ID);
        boolean business = purchase.getProducts().contains(BUSINESS_PRODUCT_ID);
        prefs.edit().putBoolean(PREMIUM, premium || isPremiumActive()).putBoolean(BUSINESS, business || isBusinessActive()).apply();
        if (!purchase.isAcknowledged()) {
            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
            billingClient.acknowledgePurchase(params, result -> listener.onBillingState(result.getResponseCode() == BillingClient.BillingResponseCode.OK ? "Purchase acknowledged" : "Purchase acknowledgement pending", premium || isPremiumActive()));
        } else listener.onBillingState("Paid plan active", premium || isPremiumActive());
    }

    public void destroy() { if (billingClient != null && billingClient.isReady()) billingClient.endConnection(); }
}

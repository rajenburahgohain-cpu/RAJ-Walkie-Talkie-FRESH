# RAJ Walkie Talkie — Supabase + WebRTC MVP

This build connects the Android WebView app to Supabase Realtime Broadcast for WebRTC signaling and uses WebRTC for live microphone audio.

## Build
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35

## Important
The app uses a Supabase **publishable** key only. Never place a Supabase secret key in the Android app.

## Current MVP
- Create an office code
- Join an office code
- Supabase Realtime channel per office
- WebRTC peer-to-peer audio
- Hold-to-talk PTT
- Speaker enable
- Multi-peer mesh signaling

For production deployment, add Supabase Auth/private Realtime channel authorization and a TURN service for networks where direct peer connectivity is unavailable.

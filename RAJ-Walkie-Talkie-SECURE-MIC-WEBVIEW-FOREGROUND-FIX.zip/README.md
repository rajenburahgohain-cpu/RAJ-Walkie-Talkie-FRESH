# RAJ Walkie Talkie

Android WebRTC + Supabase Realtime prototype.

This build fixes WebView microphone capture by loading the app through
`https://appassets.androidplatform.net/assets/index.html` using AndroidX WebViewAssetLoader,
rather than the insecure `file:///android_asset/` origin.

It also includes the Android microphone Foreground Service and runtime RECORD_AUDIO permission flow.

Important: the foreground service keeps a native service alive, but the current WebRTC peer connection
still lives in the WebView. A production 24x7 background WebRTC implementation should move the WebRTC
audio engine into the native service rather than relying on WebView JavaScript alone.
